#include <iostream>
using namespace std;

struct Estudiante
{
    string nombre;
    int codigo;
    float promedio;
};

int main()
{
  Estudiante Curso[12], 
  int op;
  FILE *p;

  do
  {
    cout<<"\nCargando.....\n\n1. Cargar datos\n2. Mostrar datos\n3. Informacion del promedio mayor y menor\n4. Promedio del curso\n5. Listado de estudiantes aprobados\n10. salir...\n Opcion:";
    cin>>op;
    switch (op)
    {
    case 1:
        p= fopen("estudiantes.txt", "r");
        for (size_t i = 0; i < 12; i++)
        {
            fscanf(p, "%d %s %f", &Curso[i].codigo, Curso[i].nombre, &Curso[i].promedio);
            cout<<"Nombre: "<<Curso[i].nombre<<", Codigo: "<<Curso[i].codigo<<", Promedio: "<<Curso[i].promedio<<endl;
        }
        fclose(p);
        break;
    case 2: 
        cout<<"Los datos ingresados fueron: "<<endl;
        for (int i = 0; i < 12; i++)
        {
            cout<<"Nombre: "<<Curso[i].nombre<<", Codigo: "<<Curso[i].codigo<<", Promedio: "<<Curso[i].promedio<<endl;
        }
        break;
    case 3:
        Estudiante mayor= Curso[0], menor= Curso[0];
        for (int i = 1; i < 12; i++)
        {
            if (Curso[i].promedio > mayor.promedio)
                mayor = Curso[i];
            else if (Curso[i].promedio < menor.promedio)
                menor = Curso[i];
        }
        cout<<"El promedio mayor del curso es: "<<endl;
        cout<<"Codigo: "<<mayor.codigo<<", Nombre: "<<mayor.nombre<<", Promedio: "<<mayor.promedio<<endl;
        cout<<"El promedio menor del curso es: "<<endl;
        cout<<"Codigo: "<<menor.codigo<<", Nombre: "<<menor.nombre<<", Promedio: "<<menor.promedio<<endl;
        break;
    case 4:
    
        float prom_curso, prom = 0;
        for (int i = 0; i < 12; i++)
        {
            prom += Curso[i].promedio;
        }
        prom_curso = prom / 12;
        cout<<"El promedio del curso es: "<<prom_curso<<endl;
        break;
    case 5:
        cout<<"Listado de estudiantes aprobados: "<<endl;
        for (int i = 0; i < 12; i++)
        {
            if (Curso[i].promedio >= 3.0)
                cout<<"Codigo: "<<Curso[i].codigo<<", Nombre: "<<Curso[i].nombre<<", Promedio: "<<Curso[i].promedio<<endl;
        }
        break;
    default:
        break;
    }
  } while (op != 10);
  return 0;
}
